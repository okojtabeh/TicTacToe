# JavaScript Tic-Tac-Toe Game

DEV env: `yarn && yarn dev`

Production build: `yarn build`

![JavaScript Minesweeper](https://raw.githubusercontent.com/uzi88/js-tic-tac-toe/master/screen-shot.png)

Demo: http://radovanjanjic.com/js-tic-tac-toe/
