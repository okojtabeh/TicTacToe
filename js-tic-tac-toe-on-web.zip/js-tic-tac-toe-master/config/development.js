module.exports = {
  inject: {
    CDN_URL: 'http://localhost:3000/',
  },
};
