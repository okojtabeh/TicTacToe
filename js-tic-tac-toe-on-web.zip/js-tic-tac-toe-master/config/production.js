module.exports = {
  inject: {
    CDN_URL: '',
  },
};
